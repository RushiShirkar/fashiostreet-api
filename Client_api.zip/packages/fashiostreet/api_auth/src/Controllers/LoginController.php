<?php

namespace fashiostreet\api_auth\Controllers;

use fashiostreet\api_auth\Layers\LayersChecker;
use fashiostreet\api_auth\Exceptions\ErrorException;
use fashiostreet\api_auth\Controllers\UserModel as UserModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use FS_Response;
use Illuminate\Support\Facades\DB;
use Validate;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    protected $request;
    protected $layerChecker;

    function __construct(Request $request)
    {
        $request = (object)$request->only(['mobile','password']);
        $this->request = $request;
        $this->layerChecker = new LayersChecker();
    }
    public function hash1()
    {
        return Hash::make($this->request->password);
    }

    public function loginview(){
        return view('api_auth::login');
    }

    protected function CredentialsValidate()
    {
        if(!Validate::numericOnly($this->request->mobile,true,0,10)) {
            throw new ErrorException('Invalid mobile number found');
        }
    }
    protected function CreateToken($user)
    {
        return encrypt($user);
    }

    public function login()
    {
        $this->CredentialsValidate();
        $user = $this->findBycredentials();
        $this->layerChecker->Logincheck($user);
        $token = $this->CreateToken($user->id);
        $local_id = $this->CreateToken($user->id);
        return FS_Response::success('data',array(
            'token' => $token,
            'local_id' => $local_id,
        ));
    }

    protected function findBycredentials()
    {
        $user = DB::select('select customer.id as id,customer.password as password from customer where mobile = ? limit 1',[$this->request->mobile]);
        if(count($user) <= 0)
        {
            throw new ErrorException('Invalid user found');
        }
        if(Hash::check($this->request->password,$user[0]->password) == 1)
        {
            return $user[0];
        }
        throw new ErrorException('Invalid mobile or password found');
    }
}
