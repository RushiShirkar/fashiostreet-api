<?php

namespace fashiostreet\product;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class users extends Model
{
    protected $table = 'users';

}
