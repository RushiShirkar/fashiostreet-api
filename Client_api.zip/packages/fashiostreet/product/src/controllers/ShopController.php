<?php

namespace fashiostreet\product;

use fashiostreet\product\Exceptions\ErrorException;
use fashiostreet\product\Exceptions\SystemException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use fashiostreet\product\city;
use fashiostreet\product\shop;
use Illuminate\Support\Facades\Redirect;
use FS_Response;

class ShopController extends Controller
{

    public function shop_search(Request $request)
    {
        if(!isset($request->shop) || !isset($request->city))
        {
            return $this->json_error('Invalid URL found');
        }
        if($request->city == null || trim($request->city) == "" || empty($request->city))
        {
            return $this->json_error('Invalid URL found');
        }
        if($request->shop == null || trim($request->shop) == "" || empty($request->shop))
        {
            return $this->json_success('');
        }

        $city = new city();
        $cityId = $city->getCityId($request->city);
        if($cityId == false){
            return $this->json_error('Invalid city name found');
        }

        try {
            $result = DB::table('shop')->select(['name'])->where('city_id',$cityId[0]->id)->where('name', 'like', $request->shop . '%')->take(5)->get();
            if (count($result) > 0) {
                return $this->json_success($result);
            }
            else {
                $request->shop = substr($request->shop, 0, 3);
                $result = DB::table('shop')->select(['name'])->where('city_id',$cityId[0]->id)->where('name', 'like', $request->shop . '%')->take(5)->get();
                if (count($result) > 0) {
                    return $this->json_success($result);
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return $this->json_error($e->getMessage());
        }
        return $this->json_success('No Shop Found');
    }

    /*
     * Get Shop name list
     * */
    public function shop_name_list(Request $request){
        $shop = DB::select('select shop.name from shop left join city on shop.city_id = city.id where city.name = ?',[$request->city]);
        return FS_Response::success('data',$shop);
    }


    public function shop_list(Request $request,$city,$json = 'view')
    {
        try
        {
            if(strtolower($request->shop) != 'all shop')
            {
                return Redirect::to('/shop/'.$city.'/available-category?shop='.$request->shop);
            }
            if(!isset($request->page))
            {
                $request->page = 1;
            }
            $min = (int)$request->page;  //page validate
            $max = 15;
            $min = (($min - 1)*$max);

            $obj = new city();
            $city_id = $obj->getCityId($city);
            if($city_id == false) {
                if($json == 'json')
                {
                    return FS_Response::error(500,'sorry we are not connected with your city right now');
                }
                return view('fashiostreet_client::404'); //convert json error to page
            }
            $data = array('city' => $city,'shop_name' => $request->shop);
            unset($city);
            $result = (array) DB::select('select id,name,image,contact,alternate_contact,address,opening_time,closing_time from shop where city_id = ? limit ?,?',[$city_id[0]->id,$min,$max]);
            $result = $this->ChangeShopImgUrl($result);
            if(!$result)
            {
                if($json == 'json'){
                    return FS_Response::error(500,'No Shop found');  //result empty array
                }
                return view('fashiostreet_client::shop_list',['data' => $data,'shops' => []]);
            }
            if(count($result) > 0)
            {
                if($json == 'json'){
                    return $result;
                }
                else if($json == 'view')
                {
                    return view('fashiostreet_client::shop_list',['data' => $data,'shops' => $result]);
                }
                else{
                    return view('fashiostreet_client::404');
                }

            }
            if($json == 'json'){
                return [];  //result empty array
            }
            return view('fashiostreet_client::shop_list',['data' => $data,'shops' => []]);

        }
        catch (\Illuminate\Database\QueryException $e)
        {
            return $e->getMessage();
            $request = array('error' => 'Server Error found '.$e->getCode());
            if($json == 0)
                return view('fashiostreet_client::error500',['request' => $request]);
            return 'Server Error Found : '.$e->getCode();
        }
    }

    /*
     * Change Shop Image path
     * */

    public function ChangeShopImgUrl($shops,$multi = null)
    {
        foreach ($shops as $shop) {
            if(isset($shop->offers) && $shop->offers != null)
            {
                $shop->offers = explode(',',$shop->offers);
            }
            if($multi != null)
            {
                $shop->image = explode(',',$shop->image);
            }
            else{
                $shop->image = env('IMAGE_URL','https://seller.fashiostreet.com').'/shops/original/'.$shop->image;
            }
        }
        return $shops;
    }

    /*
     * Add gender
     * */
    /*
     * Add size to product after product list out
     * */
    public function addGender_to_shop($shops)
    {
        try {
            foreach ($shops as $shop) {
                $gender = DB::select('select DISTINCT gender.name as gender,gender.id as id from gender left join tabs ON tabs.gender_id = gender.id where tabs.shop_id = ? ORDER by gender.id ASC ',[$shop->id]);
                $shop->{'gender'} = $gender;
                unset($gender);
            }
            return $shops;
        }
        catch (\Illuminate\Database\QueryException $e) {
            return false;
        }
    }

    /*
     * Get list of sub-category through gender
     * */
    public function shop_sub_category(Request $request)
    {
        $city = $request->city;
        $shop = $request->shop;

        $obj = new city();
        $city_id = $obj->getCityId($city);
        if($city_id == false) {
            $error = array('code' => '500', 'msg' => 'Invalid Url or City name found');
            return $this->json_error('$error'); //convert json error to page
        }
        unset($city);

        $shop_obj = new shop();
        $shop_id = $shop_obj->getShopId($city_id[0]->id,$shop);
        if($shop_id == false)
            return $this->json_error('Invalid URl or Shop name found');
        unset($shop_obj);


        try
        {
            $data = array(array(),array(),array(),array());
            $result = DB::select('select  tabs.gender_id as gender_id,sub_category.name as sub_category,category.name as category from tabs left join sub_category ON  tabs.sub_category_id = sub_category.id left join category ON  tabs.category_id = category.id where shop_id = ?',[$shop_id[0]->id]);
            for($i=0;$i < count($result);$i++)
            {
                if($result[$i]->gender_id == 1)
                {
                    array_push($data[0],array('sub_category' => $result[$i]->sub_category,'category' => $result[$i]->category));
                }
                else if($result[$i]->gender_id == 2)
                {
                    array_push($data[1],array('sub_category' => $result[$i]->sub_category,'category' => $result[$i]->category));
                }
                else if($result[$i]->gender_id == 3)
                {
                    array_push($data[2],array('sub_category' => $result[$i]->sub_category,'category' => $result[$i]->category));
                }
                else if($result[$i]->gender_id == 4)
                {
                    array_push($data[3],array('sub_category' => $result[$i]->sub_category,'category' => $result[$i]->category));
                }
            }
            return $data;

        }
        catch (\Illuminate\Database\QueryException $e)
        {
            $error = array('code' => 500,'msg' => 'Server Error Found');
            return $error;
        }

    }

    public function shop_details(Request $request)
    {
        $city = $request->city;
        $shop = $request->shop;

        $obj = new city();
        $city_id = $obj->getCityId($city);
        if($city_id == false) {
            throw new ErrorException('invalid city name found');
        }
        unset($city);

        $shop_obj = new shop();
        $shop_id = $shop_obj->getShopId($city_id[0]->id,$shop);
        if($shop_id == false)
            return $this->json_error('Invalid URl or Shop name found');
        unset($shop_obj);

        try
        {
            $shop = shop::select(['id','name','image','offers','contact','alternate_contact','address','closed_day','opening_time','closing_time'])->findOrFail($shop_id[0]->id);
            return $shop;
        }
        catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            $error = array('code' => 500,'msg' => 'No Shop Found');
            return $error;
        }
        catch (\Illuminate\Database\QueryException $e)
        {
            throw new SystemException($e->getMessage());
        }

    }


    /*
     * error json private function
     * */
    private function json_error($error)
    {
        return response()->json($error,500);
    }

    /*
     * success json private function
     * */

    private function json_success($message)
    {
        return response()->json($message,200);
    }

}
