<?php

namespace fashiostreet\product;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CityController extends Controller
{

    /*
        Get city name to city search suggestion box
    */
    public function city_search(Request $request)
    {
        if(!isset($request->q))
        {
            return $this->json_error('Invalid URL found');
        }
        if($request->q == null || trim($request->q) == "" || empty($request->q))
        {
            return $this->json_success('');
        }
        try {
            $result = DB::table('city')->select(['name'])->where('name', 'like', $request->q . '%')->take(7)->get();
            if (count($result) > 0) {
                return $this->json_success($result);
            }
            else {
                $request->q = substr($request->q, 0, 3);
                $result = DB::table('city')->select(['name'])->where('name', 'like', $request->q . '%')->take(7)->get();
                if (count($result) > 0) {
                    return $this->json_success($result);
                }
            }
        } catch (\Illuminate\Database\QueryException $e) {
            return $this->json_error($e->getMessage());
        }
        return $this->json_success('No Result Found');
    }


    /*
     * error json private function
     * */
    private function json_error($error)
    {
        return response()->json($error,500);
    }

    /*
     * success json private function
     * */

    private function json_success($message)
    {
        return response()->json($message,200);
    }
}