<?php
namespace fashiostreet\product;
use App\Http\Controllers\Controller;
use fashiostreet\product\Auth\User;
use fashiostreet\product\Traits\OrderTrait;
use fashiostreet\product\Traits\TrackerTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use FS_Response;

class OrderController extends Controller {
    use OrderTrait,TrackerTrait;
    protected $user_id;

    function __construct(Request $request)
    {
        $obj = new User();
        $this->user_id = $obj->getUserId($request);
    }

    /*
     * @param
     * address_id
     * product[{product_id,size_id,qty}]
     * @return
     * message
     * */
    public function addOrder(Request $request)
    {
        $obj = new CartController($request);
        DB::beginTransaction();
        $order = $this->createOrder($request,$this->user_id);
        $this->createOrderProductsData($order->id,$this->user_id);
        $obj->DeleteAllFromCart();
        DB::commit();
        return response()->json('successfully order placed your order id : '.$order->id);
    }
    /*
     * response : {
     *
     * }
     * */
    public function getOrderHistory(Request $request,$json='view')
    {
        $page = isset($request->page)? (int) $request->page :1;
        $paginate = 15;
        $startFrom = ($page - 1) * $paginate;
        $orderComplete = array();
        $orders = $this->getOrders($this->user_id,$startFrom,$paginate);
        for($i=0;$i < count($orders);$i++)
        {
            $tmp_data = array(
                'order_id' => $orders[$i]->order_id,
                'order_status' => $orders[$i]->status,
                'address' => $orders[$i]->address,
                'contact' => $orders[$i]->contact,
                'customer_name' => $orders[$i]->customer_name,
                'completed_at' => $orders[$i]->completed_at,
                'order_date' => $orders[$i]->created_at,
                'products' => $this->getSelectedProduct($orders[$i]->order_id)
            );
            array_push($orderComplete,$tmp_data);
            unset($tmp_data);
        }
        if($json == 'json')
        {
            return FS_Response::success('message',$orderComplete);
        }
        return view('fashiostreet_client::orders_history',['order' => $orderComplete]);
    }
    /*
     * @param
     * order_id
     * */
    public function CancelOrder(Request $request){
        return $this->ChangeOrderStatus($request->order_id,$this->user_id);
    }

    public function confirm_delivery(Request $request,$json = 'view')
    {
        $obj = new CartController($request);
        $product = $obj->GetFromCart($request,'normal');
        $obj = new AddressController($request);
        $address = $obj->getAddressById($request);
        if($json == 'json')
        {
            return FS_Response::success('data',array(
                'product' => $product,
                'address' => $address
            ));
        }
        return view('fashiostreet_client::confirm_delivery',['product' => $product,'address' => $address]);
    }
}