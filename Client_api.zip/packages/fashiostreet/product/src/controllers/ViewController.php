<?php

namespace fashiostreet\product;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Sentinel;
use FS_Response;

class ViewController extends Controller
{
    public function error(Request $request){
        return view('fashiostreet_client::error500',['request' => $request]);
    }

    // offers function for viewing all offers - Godwin

    public function offers(Request $request)
    {

        try{
            $offers = DB::select("SELECT * FROM product WHERE shop_id IN (SELECT id FROM shop WHERE offers != NULL OR offers != '') ORDER BY discount DESC");
            

            
            return FS_Response::success('data',$offers);

        }
        catch(\Illuminate\Database\QueryException $e)
        {

                return FS_Response::error(500,'Server error found');
            return view('fashiostreet_client::error500',['request' => array('error' => 'Something Goes Wrong (server error), Please try again' )]);
        }

    }

    public function main_page(Request $request)
    {
        $data = 0;
        if($user = Sentinel::getUser())
        {
            $data = 1;
        }
        return view('fashiostreet_client::home',['login_flag' => $data]);
    }

    public function getLeftJoin()
    {
        $data = array('category' =>array(
            array(
                'category' => 'MEN CLOTHING',
                'wear' => array(
                    array(
                        'wear' => "TOP WEAR",
                        "type" => array("T-Shirts","Formal Shirts","Casual Shirts","Jackets","Sweatshirts","Sweaters","Kurtas","Sherwanis","Suits","Blazers","Pullovers","Cardigans")
                    ),
                    array(
                        'wear' => "BOTTOM WEAR",
                        "type" => array("Jeans","Trousers","Cargos","Shorts and 3/4ths","Track pants","Dhotis","Lungis","Pyjamas")
                    ),
                    array(
                        'wear' => "SPORTS WEAR",
                        "type" => array("Sports T-Shirts","Track pants","Track suits","Shorts")
                    ),
                    array(
                        'wear' => "INNERWEAR AND SLEEPWEAR",
                        "type" => array("Briefs and trunks","Vests","Boxers","Thermals")
                    ),
                    array(
                        'wear' => "FABRICS",
                        'type' => array("Shirt Fabrics","Multi-purpose Fabrics","Kurta Fabrics","Trouser Fabrics","Suit Fabrics","Safari Fabrics")
                    ),
                    array(
                        'wear' => 'OTHERS',
                        'type' => array("Raincoats","Wind cheaters")
                    ),
                    array(
                        'wear' => 'ACCESSORIES',
                        'type' => array("Socks","Ties","Cufflinks","Mufflers","Scarfs","Shirt Studs","Cravats","Bandanas","Arm warmers","Pocket squares","Handkerchiefs","Suspenders","Gloves","Turbans","Towels")
                    )

                )
            ),
            array(
                'category' => 'WOMEN CLOTHING',
                'wear' => array(
                    array(
                        'wear' => "WESTERN WEAR",
                        "type" => array("Shirts","Tops","Tunics","Kaftans","BodySuits","Polos and T-Shirts","Dresses","Jeans","Trousers","Capris","Cargos","Dungarees","Shorts and Skirts","Fashion Jackets")
                    ),
                    array(
                        'wear' => "ETHNIC WEAR",
                        "type" => array("Sarees","Kurtas","Dress Material","Lehenga Choli","Blouse","Harem Pants","Patialas","Leggings","Anarkali","Salwars","Blouse Fabrics","Chudidars")
                    ),
                    array(
                        'wear' => "WINTER AND SEASONAL",
                        "type" => array("Sweaters","Pullovers","SweatShirts","Jackets","Raincoats","Windcheaters","cardigans","coats","Ponchos","Thermals","Winter Jackets","Shawls","Mufflers","Gloves","Socks")
                    ),
                    array(
                        'wear' => "SPORTS AND GYM WEAR",
                        "type" => array("Track Pants","Track Suits","Track Tops","T-Shirts","Socks and Stockings","Tights","Caps","Sports Bras","Shorts","Sports Jackets","Sarongs")
                    ),
                    array(
                        'wear' => "LINGERIE AND SLEEP WEAR",
                        'type' => array("Bras","Panties","Night Dresses and Suits","Swim and BeachWears","Gowns")
                    )
                )
            ),
            array(
                'category' => 'BABY AND KIDS',
                'wear' => array(
                    array(
                        'wear' => "BOY'S CLOTHING",
                        "type" => array("T-Shirts","Kurtas","Raincoats","Jackets","Sweatshirts","Sweaters","Pullovers")
                    ),
                    array(
                        'wear' => "BABY BOY",
                        "type" => array("Sleep Suits","Body Suits","T-Shirts")
                    ),
                    array(
                        'wear' => "BABY GIRL",
                        "type" => array("Sleep Suits","Body Suits","Baby Girl Dresses")
                    ),
                    array(
                        'wear' => "GIRL'S CLOTHING",
                        "type" => array("Dresses","Skirts","Salwar Kurtas","Kurtas","Lehenga Choli","Ethnic Sets","Sarees","Mufflers","Thermals","Sweaters","Sweatshirts","Raincoats","Jackets")
                    )
                )
            ),
        ));
        return $this->json_success($data);
    }

    public function category_shop(Request $request,$city,$json = 'view')
    {
        if(strtolower($request->shop) == 'all shop')
        {
            return Redirect::to('/shop/'.$city.'?shop=All Shop');
        }
        $request->{'city'} = $city;
        $shop = new ShopController();
        $category = $shop->shop_sub_category($request);
        if($category == false)
        {
            if($json == 'json'){
                return response()->json('Sorry,No Category Found',500);
            }
            return view('fashiostreet_client::error500',['request' => array('error' => 'Sorry,No Category Found')]);
        }
        $shop_details = $shop->shop_details($request);
        $shop_details = $shop->ChangeShopImgUrl(array($shop_details),true);
        if($shop_details == false)
        {
            if($json == 'json'){
                return response()->json('Sorry,No Shop Details Found',500);
            }
            return view('fashiostreet_client::error500',['request' => array('error' => 'Sorry,No Shop Details Found')]);
        }
        $product = new ProductController();
        $product = $product->getTop15ShopProduct($shop_details[0]->id);
        $data = array('city' => $city,'shop_name' => $request->shop);
        $data = array(
            'data' => $data,
            'category' => $category,
            'shop' => $shop_details,
            'products' => $product
        );
        if($json == 'json'){
            return response()->json($data,200);
        }
        return view('fashiostreet_client::shop_category',$data);
    }

    public function city_offer2(Request $request,$city)
    {
        return $this->city_offer($request,$city,'json');
    }

    public function city_offer(Request $request,$city,$json = 'view')
    {
        try
        {
            $products = DB::select('select product.id as id,product.image,product.name as name,product.mrp_price,product.selling_price,shop.name as shop_name from product LEFT JOIN shop ON shop.id = product.shop_id where product.id IN (214,179,59,260,528,275,417,298,45,219,180,414,274,27,674,296,19) and product.deleted_at IS NULL');
            $obj = new ProductController();
            if(gettype($products = $obj->addSize_to_product($products,2)) == "array") {
                $shops = DB::select('select id,name,image,address from shop limit 15');
                $obj = new ShopController();
                if ((($shops = $obj->ChangeShopImgUrl($shops)) != false)) {
                    if($json == 'json')
                    {
                        $images = array(
                            array(
                                'shop' => 'lifestyle',
                                'banner' => asset('/assets/img/banner1.png')
                            ),
                            array(
                                'shop' => 'HARI OM COLLECTION',
                                'banner' => asset('/assets/img/banner4.png')
                            ),
                            array(
                                'shop' => 'Lavanya NX',
                                'banner' => asset('/assets/img/banner2.png')
                            ),
                            array(
                                'shop' => 'Silverleaf Islampur',
                                'banner' => asset('/assets/img/banner5.png')
                            ),
                            array(
                                'shop' => 'Dress code',
                                'banner' => asset('/assets/img/banner3.png')
                            ),
                        );
                        return FS_Response::success('data',['products' => $products,'shops' => $shops,'images' => $images]);
                    }
                    //return ['data' => array('city' => $city, 'shop_name' => $request->shop), 'products' => $products, 'shops' => $shops];
                    return view('fashiostreet_client::city_offer', ['data' => array('city' => $city, 'shop_name' => $request->shop), 'products' => $products, 'shops' => $shops]);
                }
            }
            if($json == 'json')
            {
                return FS_Response::error(500,'Failed to load size to product');
            }
            return view('fashiostreet_client::error500',['request' => array('error' => 'Something Goes Wrong, Please try again')]);
        }
        catch(\Illuminate\Database\QueryException $e)
        {
            if($json == 'json')
            {
                return FS_Response::error(500,'Server error found');
            }
            return view('fashiostreet_client::error500',['request' => array('error' => 'Something Goes Wrong (server error), Please try again' )]);
        }
    }


    public function product_list(Request $request,$city,$sub_category,$json = 'view')
    {
        $data = array('city' => $city,'shop_name' => $request->shop,'page' => $request->page,'sub_category' => $sub_category);
        if(isset($request->q))
        {
            $data['q'] = $request->q;
        }
        $product = new ProductController();
        $product = $product->getProduct($request,$city,$sub_category,true);
        if($json == 'json')
        {
            return FS_Response::success('data',$product);
        }
        $request->{'error'} = 'Sorry!,No Product Found';
        if(gettype($product) != 'array')
        {
            if(strcasecmp($product,"Invalid Url or City name found") == 0)
            {
                $data['flag'] = 0;
            }
            $product = [];
        }
        return view('fashiostreet_client::product_list',['data' => $data,'products' => $product,'request' => $request]);
    }

    /*
     * error json private function
     * */
    private function json_error($error)
    {
        return response()->json($error,500);
    }

    /*
     * success json private function
     * */

    private function json_success($message)
    {
        return response()->json($message,200);
    }

}
