<!DOCTYPE html>
<html lang="en-in">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="DC.title" content="Fashiostreet" />
    <meta name="geo.region" content="IN-MH" />
    <meta name="geo.position" content="19.75148;75.713888" />
    <meta name="ICBM" content="19.75148, 75.713888" />

    <title>{{ $product[0]->name }} - fashiostreet</title>
    <link rel="shortcut icon" href="{{ asset('assets/img/fs_icon.png') }}">
    <link href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Core css bootstrap.min.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato|Open+Sans|Roboto|Source+Sans+Pro" rel="stylesheet">
    <!-- Google Fonts -->
    <!-- Custom StyleSheet -->
    <link rel="stylesheet" href="{{ asset('assets/css/category_city.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/category.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/prod_detail.css') }}">
    @yield('category_shop')
    <style>
        .drp{
            position:absolute;
            right:40px;
            margin-top:10px;
            font-size:18px;
        }
        .drp a
        {
            text-decoration: none;
            color:white;
        }
        .active_size{
            background-color:  #00E676  !important;
        }
        .img_modal{
            display:none;
            top:0px;
            width:100%;
            height:100vh;
            background-color:rgba(0,0,0,0.7);
            position:fixed;
            z-index:99999;
        }
        .img_modal a{
            text-decoration:none;
            font-size:22px;
        }
        .modal_close_btn{
            position:absolute;
            color:white !important;
            top:20px;
            right:40px;
        }
        .img_box{
            cursor: pointer;
        }
        .atc_btn{
            background-color:#00E676;
            color: #FFFFFF;
            font-weight: bold;
            border: 0px;
            padding: 15px;
            border-radius: 2px;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.2);
            outline: none;
        }
        .product_icon-img{
            height: 70px;
            max-width: 100%
        }

    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-120362424-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-120362424-1');
    </script>

</head>
<body class="light_gray marg-head_top1">
<center>
    <div class="toast" style="position:fixed;z-index:999999;font-size:20px;left:50%;transform:translate(-50%,0);bottom:30px;display:none;padding:10px;background-color: black;color:white;opacity: 0.8;">
    </div>
</center>
<nav class="navbar navbar-fixed-top pzero desktop">
    <div class="row pzero h_row1">
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 logo_col">
            <a href="/" class="pzero"><img src="{{ asset('assets/img/fashiostreet_logo.png') }}" style="width:135%"></a>
        </div>
        <div class="col-lg-6 col-lg-offset-1 col-md-6 col-md-offset-1 col-sm-6 col-sm-offset-1 col-xs-6 col-xs-offset-1 search_col pzero">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 pzero search_city dropdown">
                    <button class="btn search_city-btn suggestion_btn1" type="button">
                        <img style="width:20px" src="{{ asset('assets/img/location_search.png') }}"/> &nbsp {{ $data['city'] }} &nbsp<span class="glyphicon glyphicon-menu-down"></span>
                    </button>
                    <div id="city_suggestion" class="suggestion_div z-depth-3">
                        <ul>
                            <li>
                                <div class="input-group">
                                    <form id="city_selector_form" action="#">
                                        <input type="search" id="city_search_txt" class="form-control" name="search_city" placeholder="Search City" autocomplete="off">
                                    </form>
                                </div>
                            </li>
                            <div class="city_suggestion_box">
                            </div>
                            <div style="padding: 0px 8px">
                            <p>LAUNCHING SOON IN ....</p>
                            <p>Kolhapur</p>
                            <p>Satara</p>
                            <p>Pune</p>
                            </div>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 pzero">
                    <form id="search_product_form">
                        <input type="text" id="product_search_txt" class="mzero search_pro" placeholder="Search Product in this city" autocomplete="off">
                    </form>
                    <div class="suggestion_div z-depth-3 product_suggestion_div" style="display:block !important;background-color: white !important;">
                    </div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 pzero">
                    <button class="search_btn">
                        <span class="glyphicon glyphicon-search"></span>
                    </button>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 pzero">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 selectshop_col">
                    <a href="/shop/{{ $data['city'] }}?shop=All%20Shop" class="btn selectshop_btn" style="color: #000000 !important;">
                       <img src="{{ asset('assets/img/store.png') }}">&nbsp; All Shops 
                    </a>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 sign_col">
                    <a href="https://play.google.com/store/apps/details?id=com.shoping_search_engine.fashiostreet" class="home_signInUp pull-right" target="_blank" style="margin: 0px">DOWNLOAD APP</a>
                </div>
            </div>
        </div>
    </div>
    <div style="background: #263238;">
        <div class="menu-container">
            <div class="menu">
                <ul>
                    <li><a href="javascript:void(0)" class="cat_title">MEN <span class="glyphicon glyphicon-menu-down" style="font-size: 12px"></span></a>
                        <ul>
                            <li><a href="javascript:void(0)">Top Wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/T-shirts?shop={{ $data['shop_name'] }}&gender=men&category=top wear">T-Shirts</a></li>
                                    <li><a href="/product/Islampur/Formal shirts?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Formal Shirts</a></li>
                                    <li><a href="/product/Islampur/Casual shirts?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Casual Shirts</a></li>
                                    <li><a href="/product/Islampur/Jackets?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Jackets</a></li>
                                    <li><a href="/product/Islampur/Sweatshirts?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Sweatshirts</a></li>
                                    <li><a href="/product/Islampur/Sweaters?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Sweaters</a></li>
                                    <li><a href="/product/Islampur/Kurtas?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Kurtas</a></li>
                                    <li><a href="/product/Islampur/Sherwanis?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Sherwanis</a></li>
                                    <li><a href="/product/Islampur/Suits?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Suits</a></li>
                                    <li><a href="/product/Islampur/Blazers?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Blazers</a></li>
                                    <li><a href="/product/Islampur/Pullovers?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Pullovers</a></li>
                                    <li><a href="/product/Islampur/Cardigans?shop={{ $data['shop_name'] }}&gender=men&category=top wear">Cardigans</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0)">Bottom Wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Jeans?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Jeans</a></li>
                                    <li><a href="/product/Islampur/Trousers?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Trousers</a></li>
                                    <li><a href="/product/Islampur/Cargos?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Cargos</a></li>
                                    <li><a href="/product/Islampur/Shorts and 3 by 4ths?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Shorts & 3/4ths</a></li>
                                    <li><a href="/product/Islampur/Track pants?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Track pants</a></li>
                                    <li><a href="/product/Islampur/Dhotis?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Dhotis</a></li>
                                    <li><a href="/product/Islampur/Lungis?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Lungis</a></li>
                                    <li><a href="/product/Islampur/Pyjamas?shop={{ $data['shop_name'] }}&gender=men&category=bottom wear">Pyjamas</a></li>
                                </ul>
                                <a href="javascript:void(0)">Sports wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Sports T-Shirts?shop={{ $data['shop_name'] }}&gender=men&category=sports wear">Sports T-Shirts</a></li>
                                    <li><a href="/product/Islampur/Track pants?shop={{ $data['shop_name'] }}&gender=men&category=sports wear">Track pants</a></li>
                                    <li><a href="/product/Islampur/Track Suits?shop={{ $data['shop_name'] }}&gender=men&category=sports wear">Track suits</a></li>
                                    <li><a href="/product/Islampur/Shorts?shop={{ $data['shop_name'] }}&gender=men&category=sports wear">Shorts</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0)">Innerwear & Sleepwear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Briefs and trunks?shop={{ $data['shop_name'] }}&gender=men&category=innerwear and sleepwear">Briefs & trunks</a></li>
                                    <li><a href="/product/Islampur/Vests?shop={{ $data['shop_name'] }}&gender=men&category=innerwear and sleepwear">Vests</a></li>
                                    <li><a href="/product/Islampur/Boxers?shop={{ $data['shop_name'] }}&gender=men&category=innerwear and sleepwear">Boxers</a></li>
                                    <li><a href="/product/Islampur/Thermals?shop={{ $data['shop_name'] }}&gender=men&category=innerwear and sleepwear">Thermals</a></li>
                                </ul>
                                <a href="javascript:void(0)">Fabrics</a>
                                <ul>
                                    <li><a href="/product/Islampur/Shirt Fabrics?shop={{ $data['shop_name'] }}&gender=men&category=fabrics">Shirt fabrics</a></li>
                                    <li><a href="/product/Islampur/Multi-purpose Fabrics?shop={{ $data['shop_name'] }}&gender=men&category=fabrics">Multi-purpose fabrics</a></li>
                                    <li><a href="/product/Islampur/Kurta Fabrics?shop={{ $data['shop_name'] }}&gender=men&category=fabrics">Kurta fabrics</a></li>
                                    <li><a href="/product/Islampur/Trouser Fabrics?shop={{ $data['shop_name'] }}&gender=men&category=fabrics">Trouser fabrics</a></li>
                                    <li><a href="/product/Islampur/Suit Fabrics?shop={{ $data['shop_name'] }}&gender=men&category=fabrics">Suit fabrics</a></li>
                                    <li><a href="/product/Islampur/Safari Fabrics?shop={{ $data['shop_name'] }}&gender=men&category=fabrics">Safari fabrics</a></li>
                                </ul>
                                <a href="javascript:void(0)">Others</a>
                                <ul>
                                    <li><a href="/product/Islampur/Raincoats?shop={{ $data['shop_name'] }}&gender=men&category=others">Raincoats</a></li>
                                    <li><a href="/product/Islampur/Wind Cheaters?shop={{ $data['shop_name'] }}&gender=men&category=others">Wind cheaters</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0)">Accessories</a>
                                <ul>
                                    <li><a href="/product/Islampur/Socks?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Socks</a></li>
                                    <li><a href="/product/Islampur/Ties?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Ties</a></li>
                                    <li><a href="/product/Islampur/Cufflinks?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Cufflinks</a></li>
                                    <li><a href="/product/Islampur/Mufflers?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Mufflers</a></li>
                                    <li><a href="/product/Islampur/Scarfs?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Scarfs</a></li>
                                    <li><a href="/product/Islampur/Shirts Studs?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Shirt Studs</a></li>
                                    <li><a href="/product/Islampur/Cravats?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Cravats</a></li>
                                    <li><a href="/product/Islampur/Bandanas?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Bandanas</a></li>
                                    <li><a href="/product/Islampur/Arm Warmers?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Arm warmers</a></li>
                                    <li><a href="/product/Islampur/Pocket Squares?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Pocket squares</a></li>
                                    <li><a href="/product/Islampur/Handkerchiefs?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Handkerchiefs</a></li>
                                    <li><a href="/product/Islampur/Suspenders?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Suspenders</a></li>
                                    <li><a href="/product/Islampur/Gloves?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Gloves</a></li>
                                    <li><a href="/product/Islampur/Turbans?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Turbans</a></li>
                                    <li><a href="/product/Islampur/Towels?shop={{ $data['shop_name'] }}&gender=men&category=accessories">Towels</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="javascript:void(0)" class="cat_title">WOMEN <span class="glyphicon glyphicon-menu-down" style="font-size: 12px"></span></a>
                        <ul>
                            <li><a href="javascript:void(0)">Western Wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Shirts?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Shirts</a></li>
                                    <li><a href="/product/Islampur/Tops?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Tops</a></li>
                                    <li><a href="/product/Islampur/Tunics?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Tunics</a></li>
                                    <li><a href="/product/Islampur/Kaftans?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Kaftans</a></li>
                                    <li><a href="/product/Islampur/Single one piece?shop={{ $data['shop_name'] }}&gender=women&category=western wear">One Piece</a></li>
                                    <li><a href="/product/Islampur/Bodysuits?shop={{ $data['shop_name'] }}&gender=women&category=western wear">BodySuits</a></li>
                                    <li><a href="/product/Islampur/T-Shirts?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Polos and T-Shirts</a></li>
                                    <li><a href="/product/Islampur/Dresses?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Dresses</a></li>
                                    <li><a href="/product/Islampur/Jeans?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Jeans</a></li>
                                    <li><a href="/product/Islampur/Trousers?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Trousers</a></li>
                                    <li><a href="/product/Islampur/Capris?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Capris</a></li>
                                    <li><a href="/product/Islampur/Cargos?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Cargos</a></li>
                                    <li><a href="/product/Islampur/Dungarees?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Dungarees</a></li>
                                    <li><a href="/product/Islampur/Shorts and Skirts?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Shorts & Skirts</a></li>
                                    <li><a href="/product/Islampur/Fashion Jackets?shop={{ $data['shop_name'] }}&gender=women&category=western wear">Fashion Jackets</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Ethnic Wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Sarees?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Sarees</a></li>
                                    <li><a href="/product/Islampur/Kurtis?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Kurtis</a></li>
                                    <li><a href="/product/Islampur/Dress Material?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Dress Material</a></li>
                                    <li><a href="/product/Islampur/Lehenga Choli?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Lehenga Choli</a></li>
                                    <li><a href="/product/Islampur/Blouse?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Blouse</a></li>
                                    <li><a href="/product/Islampur/Harem Pants?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Harem Pants</a></li>
                                    <li><a href="/product/Islampur/Patialas?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Patialas</a></li>
                                    <li><a href="/product/Islampur/Leggings?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Leggings</a></li>
                                    <li><a href="/product/Islampur/Anarkali?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Anarkali</a></li>
                                    <li><a href="/product/Islampur/Salwars?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Salwars</a></li>
                                    <li><a href="/product/Islampur/Blouse Fabric?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Blouse Fabrics</a></li>
                                    <li><a href="/product/Islampur/Chudidars?shop={{ $data['shop_name'] }}&gender=women&category=ethnic wear">Chudidars</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Winter & Seasonal</a>
                                <ul>
                                    <li><a href="/product/Islampur/Sweaters?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Sweaters</a></li>
                                    <li><a href="/product/Islampur/Pullovers?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Pullovers</a></li>
                                    <li><a href="/product/Islampur/Sweatshirts?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">SweatShirts</a></li>
                                    <li><a href="/product/Islampur/Jackets?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Jackets</a></li>
                                    <li><a href="/product/Islampur/Raincoats?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Raincoats</a></li>
                                    <li><a href="/product/Islampur/Windcheaters?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Windcheaters</a></li>
                                    <li><a href="/product/Islampur/Cardigans?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">cardigans</a></li>
                                    <li><a href="/product/Islampur/Coats?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">coats</a></li>
                                    <li><a href="/product/Islampur/Ponchos?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Ponchos</a></li>
                                    <li><a href="/product/Islampur/Thermals?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Thermals</a></li>
                                    <li><a href="/product/Islampur/Winter Jackets?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Winter Jackets</a></li>
                                    <li><a href="/product/Islampur/Shawls?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Shawls</a></li>
                                    <li><a href="/product/Islampur/Mufflers?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Mufflers</a></li>
                                    <li><a href="/product/Islampur/Gloves?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Gloves</a></li>
                                    <li><a href="/product/Islampur/Socks?shop={{ $data['shop_name'] }}&gender=women&category=winter and seasonal">Socks</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Sports & Gym Wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Track Pants?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Track Pants</a></li>
                                    <li><a href="/product/Islampur/Track Suits?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Track Suits</a></li>
                                    <li><a href="/product/Islampur/Track Tops?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Track Tops</a></li>
                                    <li><a href="/product/Islampur/T-shirts?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">T-Shirts</a></li>
                                    <li><a href="/product/Islampur/Socks and Stockings?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Socks & Stockings</a></li>
                                    <li><a href="/product/Islampur/Tights?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Tights</a></li>
                                    <li><a href="/product/Islampur/Caps?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Caps</a></li>
                                    <li><a href="/product/Islampur/Sports Bras?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Sports Bras</a></li>
                                    <li><a href="/product/Islampur/Shorts?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Shorts</a></li>
                                    <li><a href="/product/Islampur/Sports Jackets?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Sports Jackets</a></li>
                                    <li><a href="/product/Islampur/Sarongs?shop={{ $data['shop_name'] }}&gender=women&category=sports and gym wear">Sarongs</a></li>
                                </ul>
                                <a href="#">Lingerie & Sleep Wear</a>
                                <ul>
                                    <li><a href="/product/Islampur/Bras?shop={{ $data['shop_name'] }}&gender=women&category=Lingerie and sleep wear">Bras</a></li>
                                    <li><a href="/product/Islampur/Panties?shop={{ $data['shop_name'] }}&gender=women&category=Lingerie and sleep wear">Panties</a></li>
                                    <li><a href="/product/Islampur/Night Dresses and Suits?shop={{ $data['shop_name'] }}&gender=women&category=Lingerie and sleep wear">Night Dresses & Suits</a></li>
                                    <li><a href="/product/Islampur/Swim and BeachWears?shop={{ $data['shop_name'] }}&gender=women&category=Lingerie and sleep wear">Swim & BeachWears</a></li>
                                    <li><a href="/product/Islampur/Gowns?shop={{ $data['shop_name'] }}&gender=women&category=Lingerie and sleep wear">Gowns</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="javascript:void(0)" class="cat_title">BABY & KIDS <span class="glyphicon glyphicon-menu-down" style="font-size: 12px"></span></a>
                        <ul>
                            <li><a href="javascript:void(0)">Boy's Clothing</a>
                                <ul>
                                    <li><a href="/product/Islampur/T-shirts?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Polos & T-Shirts</a></li>
                                    <li><a href="/product/Islampur/Kurtas?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Kurtas</a></li>
                                    <li><a href="/product/Islampur/Raincoats?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Raincoats</a></li>
                                    <li><a href="/product/Islampur/Jackets?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Jackets</a></li>
                                    <li><a href="/product/Islampur/Sweatshirts?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Sweatshirts</a></li>
                                    <li><a href="/product/Islampur/Sweaters?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Sweaters</a></li>
                                    <li><a href="/product/Islampur/Pullovers?shop={{ $data['shop_name'] }}&gender=baby and kids&category=boy's clothing">Pullovers</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0)">Baby Boy</a>
                                <ul>
                                    <li><a href="/product/Islampur/Sleep Suits?shop={{ $data['shop_name'] }}&gender=baby and kids&category=baby boy">Sleep Suits</a></li>
                                    <li><a href="/product/Islampur/Bodysuits?shop={{ $data['shop_name'] }}&gender=baby and kids&category=baby boy">Body Suits</a></li>
                                    <li><a href="/product/Islampur/T-shirts?shop={{ $data['shop_name'] }}&gender=baby and kids&category=baby boy">Polos & T-Shirts</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0)">Baby Girl</a>
                                <ul>
                                    <li><a href="/product/Islampur/Sleep Suits?shop={{ $data['shop_name'] }}&gender=baby and kids&category=baby girl">Sleep Suits</a></li>
                                    <li><a href="/product/Islampur/Bodysuits?shop={{ $data['shop_name'] }}&gender=baby and kids&category=baby girl">Body Suits</a></li>
                                    <li><a href="/product/Islampur/Baby Girl Dresses?shop={{ $data['shop_name'] }}&gender=baby and kids&category=baby girl">Baby Girl Dresses</a></li>
                                </ul>
                            </li>
                            <li><a href="javascript:void(0)">Girl's Clothing</a>
                                <ul>
                                    <li><a href="/product/Islampur/Dresses?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Dresses</a></li>
                                    <li><a href="/product/Islampur/Skirts?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Skirts</a></li>
                                    <li><a href="/product/Islampur/Salwar Kurtas?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Salwar Kurtas</a></li>
                                    <li><a href="/product/Islampur/Kurtas?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Kurtas</a></li>
                                    <li><a href="/product/Islampur/Lehenga Choli?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Lehenga Choli</a></li>
                                    <li><a href="/product/Islampur/Ethnic Sets?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Ethnic Sets</a></li>
                                    <li><a href="/product/Islampur/Sarees?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Sarees</a></li>
                                    <li><a href="/product/Islampur/Mufflers?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Mufflers</a></li>
                                    <li><a href="/product/Islampur/Thermals?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Thermals</a></li>
                                    <li><a href="/product/Islampur/Sweaters?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Sweaters</a></li>
                                    <li><a href="/product/Islampur/Sweatshirts?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Sweatshirts</a></li>
                                    <li><a href="/product/Islampur/Raincoats?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Raincoats</a></li>
                                    <li><a href="/product/Islampur/Jackets?shop={{ $data['shop_name'] }}&gender=baby and kids&category=girl's clothing">Jackets</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<!-- mobile header -->
<div class="row back mob_head" style="padding:10px 0 !important">
    <div class="col-xs-2 padsearchselect" >
        @php
            $url = $_SERVER['REQUEST_URI'];
            $pre_url = url()->previous();
            $flag1 = strcasecmp($pre_url,$url);
            if($flag1 == 0)
            {
        @endphp
        <a data-flag="{{ $flag1 }}" href="/product/{{ $data['city'] }}/{{ $product[0]->sub_category }}?shop={{ $product[0]->shop_name }}&gender={{ $product[0]->gender }}&category={{ $product[0]->category }}"><i class="fa fa-angle-left textcolor height" aria-hidden="true" style="font-size:30px"></i></a>
        @php
            }
            else{
        @endphp
        <a data-flag="{{ $flag1 }}" href="{{ $pre_url }}"><i class="fa fa-angle-left textcolor height" aria-hidden="true" style="font-size:30px"></i></a>
        @php
            }
            unset($flag1);
        @endphp
    </div>
    <div class="col-xs-3 padsearchselect">
        <a href="/"><img src="{{ asset('assets/img/fs_icon.png') }}" style="max-height:35px;"></a>
    </div>
</div>
<!-- mobile header -->
<!-- box-shadow: 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2), 0 1px 5px 0 #CDDC39; -->
<div class="container-fluid" style="background:white;padding-bottom:40px;">
    <div class="row">
        <div class="col-md-1 img_col">
            @for($i=0;$i < count($product[0]->image);$i++)
                <div class="thumbnail js_p_small_img" style="margin-bottom: 10px">
                    <center>
                        <img src="{{ $product[0]->image[$i] }}" class="img-responsive product_icon-img">
                    </center>
                </div>
            @endfor
        </div>
        <div class="col-md-3 img_col">
            <div class="row">
                <div class="col-12 thumbnail img_box">
                    <center>
                        <img src="{{ $product[0]->image[0] }}" class="img-responsive product_img js_p_big_img">
                    </center>
                </div>
                <div class="col-12">
                    <a href="https://play.google.com/store/apps/details?id=com.shoping_search_engine.fashiostreet" class="btn atc_btn btn-block" target="_blank">DOWNLOAD APP TO ORDER</a>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="col-xs-12 menu_show" style="padding:10px 0;text-align: left;">
                <a href="/shop/{{ $product[0]->city }}?shop=All Shop"><span>{{ $product[0]->city }}</span></a> >
                <a href="/shop/{{ $product[0]->city }}/available-category?shop={{ $product[0]->shop_name }}"><span> {{ $product[0]->shop_name }}</span></a> >
                <a href="/product/{{ $product[0]->city }}/{{ $product[0]->sub_category }}?shop={{ $product[0]->shop_name }}&gender={{ $product[0]->gender }}&category={{ $product[0]->category }}"><span> {{ $product[0]->gender }} - {{ $product[0]->sub_category }}</span></a>
            </div>
            <h5 class="product_name">{{ $product[0]->name }}</h5>
            <span class="product_shop">Store : {{ $product[0]->shop_name }}</span>
            <br><br>
            <div>
                <label class="product_price"><span class="fa fa-inr"></span>&nbsp;{{ $product[0]->selling_price }}</label>
                <label class="cutPrice"><span class="fa fa-inr"></span>&nbsp;{{ $product[0]->mrp_price }}</label>
                <label style="color: #00E676">&nbsp;(Max Bargain Price)</label>
                <br>
                <label style="color: #FF6D00"><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp; Price are same that are in shops, we don't take commission from your side. So, order freely !</label>
            </div>
            <hr>
            <div class="col-md-6">
                <h5 class="heading"><img src="{{ asset('assets/img/resize_option.png') }}">&nbsp;&nbsp;Available Sizes</h5>
                @for($i=0;$i<count($product[0]->size);$i++)
                    <span data-size="{{ $product[0]->size[$i]->size }}" style="padding:10px;margin-left:5px;cursor: pointer" class="font20 badge js_size_btn">{{ $product[0]->size[$i]->size }}</span>
                @endfor
            </div>
            <div class="col-md-6">
                <h5 class="heading"><img src="{{ asset('assets/img/pantone.png') }}">&nbsp;&nbsp;Available Colors</h5>
                @php
                    if($product[0]->color == null){
                        $product[0]->color = [];
                    }
                    else{
                        $product[0]->color = explode(",",$product[0]->color);
                    }
                @endphp
                @for($i=0;$i < count($product[0]->color);$i++)
                    <label class="sizes"><span class="fa fa-square" style="color:{{ $product[0]->color[$i] }}"></span>&nbsp;&nbsp;{{ $product[0]->color[$i] }}</label>
                @endfor
            </div>
            <div class="col-md-12" style="margin-bottom: 15px">
                <h5 class="heading" style="padding-top: 10px">Description</h5>
                <label class="descr">{{ $product[0]->description }}</label>
                <br>
            </div>
            <hr>
            <div class="col-md-12" style="margin-bottom: 25px">
                <p style="color: #00E676;font-weight: 700;font-size: 15px;margin: 0px;padding:10px 0px">
                    <span class="glyphicon glyphicon-exclamation-sign menu_icon"></span>&nbsp;&nbsp; We Provide Free Home Delivery
                </p>
                <p style="color: #00E676;font-weight: 700;font-size: 15px;margin: 0px">
                    <span class="glyphicon glyphicon-fire menu_icon"></span>&nbsp;&nbsp; We Give TRY & BUY Feature (See More.. in HD CART)
                </p>
            </div>
            <hr>
            <div class="col-md-12"><h5 class="text-center" style="font-size: 22px;padding: 10px 0"><span class="fa fa-building" style="color:#7191A8"></span>&nbsp;Shop Details</h5></div>
            <div class="col-md-6">
                <h5 class="heading">Available At</h5>
                <label class="sizes" style="color: #0288D1 !important">{{ $product[0]->shop_name }}</label>
            </div>
        </div>
    </div>
</div>

<br/>
<!-- **************************************______Footer______*********************************-->
<footer>
    <div class="container" style="padding-top: 25px">
        <div class="row">
            <div class="col-md-7" style="padding-top:30px">
                <div class="form-group" style="display: inline-block;">
                    <center>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/aboutus.html" class="footerlinks">About Us</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com" class="footerlinks">Sell On Fashiostreet</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/contactus.html" class="footerlinks">Contact Us</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/policies.html" class="footerlinks">Listing Policy</a>
                        </div>
                    </center>
                </div>
                <br><br>
                <div class="form-group" style="display: inline-block;">
                    <center>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/help.html" class="footerlinks">Help</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/policies.html" class="footerlinks">Privacy Policy</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/term_condition.html" class="footerlinks">Terms of use</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://careers.fashiostreet.com" class="footerlinks">Careers</a>
                        </div>
                    </center>
                </div>
            </div>
            <div class="col-md-5" style="text-align: center">
                <h4 class="font_class">Follow Us On</h4>
                <a href="https://www.facebook.com/fashiostreet/" class="facebook" target="_blank">
                    <i class="fa fa-facebook-square" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://twitter.com/Fashiostreet10/" class="twitter" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://www.instagram.com/fashiostreet10/" class="Insta" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://www.linkedin.com/company/fashiostreet/" class="linkedIn" target="_blank">
                    <i class="fa fa-linkedin-square" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://plus.google.com/u/0/105052627957777439787" class="google" target="_blank">
                    <i class="fa fa-google" aria-hidden="true"></i>
                </a>
                <a href="https://msg91.com/startups/?utm_source=startup-banner" target="_blank"  style="margin-top:-10px"><img src="https://msg91.com/images/startups/msg91Badge.png" id="msg91" width="70" height="50" title="MSG91 - SMS for Startups" alt="Bulk SMS - MSG91"></a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <p class="text-center font_class" ><i class="fa fa-copyright" aria-hidden="true"></i>&nbsp;Copyright 2017  @  FashioStreet.&nbsp;&nbsp;All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

<!-- **************************************______Footer______*********************************-->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/category.js') }}"></script>
<script src="{{ asset('assets/js/main.js') }}"></script>
<script>
    $(document).ready(function(){
        var size = null;
        var clearTime = null;
        $('js_size_btn').removeClass('active_size');
        $('.js_size_btn[data-size='+ size +']').addClass('active_size');
        $('.modal_close_btn').click(function(){
            $('.img_modal').hide();
        });


        $(document).on('click','.js_p_small_img',function(){
            var img = $(this).children('center').children('img').attr('src');
            console.log(img);
            $('.js_p_big_img').attr('src',img);
            console.log($('.js_p_big_img').attr('src'));
        });
        $(document).on('click','.js_size_btn',function () {
            size = $(this).attr('data-size');
            $('.js_size_btn').removeClass('active_size');
            $(this).addClass('active_size');
            $('.toast').show().html(size + ' size selected');
            clearTimeout(clearTime);
            clearTime = setTimeout(function () {
                $('.toast').hide();
            }, 2000);
        });
        $(document).on('click','.js_add_to_cart',function () {
            if(localStorage.getItem('token') == null && localStorage.getItem('local_id') == null)
            {
                $('.toast').show().html('please login to add product into cart <a href="/api/auth/login">login</a>');
                clearTimeout(clearTime);
                clearTime = setTimeout(function () {
                    $('.toast').hide();
                }, 2000);
                return false;
            }
            if(size != null)
            {
                $.ajax({
                    type: 'post',
                    url: 'http://localhost/laravel/fashiostreet_client/public/user/addtocart',
                    data: {
                        'product_id': $(this).attr('data-id'),
                        'size' : size,
                        'qty' : 1
                    },
                    success: function (response) {
                        $('.toast').show().html('product successfully added to cart');
                        clearTimeout(clearTime);
                        clearTime = setTimeout(function () {
                            $('.toast').hide();
                        }, 3000);
                    },
                    error: function (request, status, error) {
                        var error_msg = 'failed to add product to cart';
                        if(request.responseJSON.message != undefined)
                        {
                           error_msg =  request.responseJSON.message;
                        }
                        $('.toast').show().html(error_msg);
                        clearTimeout(clearTime);
                        clearTime = setTimeout(function () {
                            $('.toast').hide();
                        }, 2000);
                    }
                });
            }
            else{
                $('.toast').show().html('please select size first');
                clearTimeout(clearTime);
                clearTime = setTimeout(function(){
                    $('.toast').hide();
                },2000);
            }
        });
        var token = localStorage.getItem('token');
        var local_id = localStorage.getItem('local_id');
        if(token != null || local_id != null)
        {
            $('.js_hide_login').hide();
            $('.js_show_login').show();
        }
        else{
            $('.js_hide_login').show();
            $('.js_show_login').hide();
        }
        var _0x1a83=["\x63\x6C\x69\x63\x6B","\x2E\x6A\x73\x5F\x6C\x6F\x67\x6F\x75\x74","\x6C\x6F\x63\x61\x6C\x5F\x69\x64","\x72\x65\x6D\x6F\x76\x65\x49\x74\x65\x6D","\x74\x6F\x6B\x65\x6E","\x75\x73\x65\x72\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6C\x6C\x79\x20\x6C\x6F\x67\x6F\x75\x74","\x68\x74\x6D\x6C","\x73\x68\x6F\x77","\x2E\x74\x6F\x61\x73\x74","\x68\x69\x64\x65","\x6F\x6E"];$(document)[_0x1a83[10]](_0x1a83[0],_0x1a83[1],function(){localStorage[_0x1a83[3]](_0x1a83[2]);localStorage[_0x1a83[3]](_0x1a83[4]);$(_0x1a83[8])[_0x1a83[7]]()[_0x1a83[6]](_0x1a83[5]);clearTimeout(clearTime);clearTime= setTimeout(function(){$(_0x1a83[8])[_0x1a83[9]]()},2000)})
    });
</script>
</body>
</html>