@extends('fashiostreet_client::layout.frame')

@section('title','fashiostreet - '.$data['city'])

@section('script')
    <script src="{{ asset('assets/js/shop_city_list.js') }}"></script>
@endsection

@section('body')

@endsection
