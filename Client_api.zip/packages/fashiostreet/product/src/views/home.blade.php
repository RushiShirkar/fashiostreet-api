<!DOCTYPE html>
<html lang="en-in">
<head>

    <title>Online Local Shopping Search Engine - Fashiostreet</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="Keywords" content="online shopping, local shopping, home delivery, fashion shopping, online shopping site, local shopping search engine, fs, fashionstreet, fashiostreet, clothing, watches, footwear"/>
    <meta name="Description" content="Local Shopping Search Engine for fashion and lifestyle in india. Get Free Home Delivery from your city's local shop. Buy clothing, shoes, watches, accessories for women & men. Best local online fashion store * COD * FREE HOME DELIVERY * TRY & BUY Feature"/>
    <link rel="canonical" href="https://www.fashiostreet.com"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="DC.title" content="Fashiostreet" />
    <meta name="geo.region" content="IN-MH" />
    <meta name="geo.position" content="19.75148;75.713888" />
    <meta name="ICBM" content="19.75148, 75.713888" />

    <link rel="shortcut icon" href="{{ asset('assets/img/fs_icon.png') }}">
    <!-- Core css bootstrap.min.css -->
    <link href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Core css bootstrap.min.css -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Google Fonts StyleSheet -->
    <link href="https://fonts.googleapis.com/css?family=Lato|Roboto|Source+Sans+Pro" rel="stylesheet">
    <!-- Google Fonts StyleSheet -->
    <!-- Custom StyleSheet -->
    <link rel="stylesheet" href="{{ asset('assets/css/StyleSheet.css') }}">
    <!-- Custom StyleSheet -->
    <style type="text/css">
        body{
            background-color: #263238;
        }
        .drp{
            position:absolute;
            right:40px;
            margin-top:10px;
            font-size:18px;
        }
        .drp a
        {
            text-decoration: none;
            color:white;
        }
        .container-fluid
        {
            background-color:#37474F;
            /* background: #CB356B;  /* fallback for old browsers */
        }
        .city{
            background-image: url({{ asset('assets/img/location_search.png') }});
        }
        #suggestion_div div a{
            display: block;
            text-decoration: none;
            color:black;
            padding:5px 5%;
        }
        #suggestion_div div a:hover{
            color:darkorange;
        }
        #suggestion_div div:hover{
            background-color: rgb(245,245,245);
        }
        .triangle{
    border-style: solid;
    border-width: 9px;
    border-color: transparent;
    border-top-width: 0;
    border-bottom: 9px solid #FFFFFF;
    width: 0;
    height: 0;
    font-size: 0;
    line-height: 0;
    position: absolute;
    top: -9px;
}
.cat-profile_content{
  display: none;
  position: absolute;
  background-color: #FFFFFF;
  min-width:170px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  right: 0px;
  border-radius:2px;
  margin-top: 40px;
}
.cat-profile_content ul{
  padding: 10px;
  margin: 0px
}
.cat-profile_content li {
  color: black;
  padding: 8px 5px;
  text-decoration: none;
  display: block;
}
.cat-profile_content li a {
  color: gray;
  text-decoration: none;
  display: block;
}
.cat-profile_content li a:hover{
  color: black;
}
.cat-profile:hover .cat-profile_content{
  display: block !important;
}
.cat-sign_btn{
  background-color:gray;
  display: block;
  color: #FFFFFF !important;
  padding:8px 0px;
}
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-120362424-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-120362424-1');
    </script>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-3 col-lg-offset-9 col-md-3 col-md-offset-9 col-sm-3 col-sm-offset-9 col-xs-3 col-xs-offset-9">
                        <a href="https://play.google.com/store/apps/details?id=com.shoping_search_engine.fashiostreet" class="home_signInUp pull-right" target="_blank" style="margin: 0px;padding: 10px">DOWNLOAD OUR APP TO ORDER</a>
                </div>
    </div>
</div>
<!-- ________________________________Container for Search Bar_______________________________-->
<div class="container-fluid home_container">
    <div class="row" style="margin-bottom: 10px">
        <div class="col-md-12">
            <center>
                <a href="javascript:void(0)"><img src="{{ asset('assets/img/fashiostreet_logo.png') }}" class="img-responsive"></a>
                <br>
                <p style="color: #00E676;letter-spacing: 3px;font-size: 17px;word-spacing: 4px;font-weight: 700">GET BEST OUT OF YOUR CITY</p>
            </center>
        </div>
    </div>
    <div class="row">
        <center>
            <div class="col-md-12">
                <div class="input-group">
                    <form id="city_form">
                        {{ csrf_field() }}
                        <div id="city_txt" class="input-group">
                            <input type="text" id="city_txtbox" class="city" placeholder="Search Your City  example : Islampur" autocomplete="off" name="city1" required>
                            <a id="clear_btn" href="javascript:void(0)"><span style="position: absolute;right:8px;bottom:8px;font-size:18px;background-color: white">clear</span></a>
                        </div>
                    </form>
                    <div id="suggestion_div" style="padding:1px;border-top:1px solid gray;background-color: white;color:gray;position:absolute;text-align: left;z-index:9999;display:none;" >
                        <div><a href="/product/Islampur?shop=All Shop">Islampur</a></div>
                        <div style="padding: 5px 5%">LAUNCHING SOON IN ....</div>
                        <div style="padding: 5px 5%">Kolhapur</div>
                        <div style="padding: 5px 5%">Satara</div>
                        <div style="padding: 5px 5%">Pune</div>
                        <div style="padding: 5px 5%">Karad</div>
                    </div>
                </div>
            </div>
        </center>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12">
            <center>
                <h4 class="text-center tag_line">India's Local Shopping Search Engine</h4>
            </center>
        </div>
    </div>
</div>

<!-- **************************************______Footer______*********************************-->
<footer>
    <div class="container" style="padding-top: 25px">
        <div class="row">
            <div class="col-md-7" style="padding-top:30px">
                <div class="form-group" style="display: inline-block;">
                    <center>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/aboutus.html" class="footerlinks">About Us</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com" class="footerlinks">Sell On Fashiostreet</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/contactus.html" class="footerlinks">Contact Us</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/policies.html" class="footerlinks">Listing Policy</a>
                        </div>
                    </center>
                </div>
                <br><br>
                <div class="form-group" style="display: inline-block;">
                    <center>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/help.html" class="footerlinks">Help</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/policies.html" class="footerlinks">Privacy Policy</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://help.fashiostreet.com/term_condition.html" class="footerlinks">Terms of use</a>
                        </div>
                        <div class="footerLink_section">
                            <a target="_blank" href="https://careers.fashiostreet.com" class="footerlinks">Careers</a>
                        </div>
                    </center>
                </div>
            </div>
            <div class="col-md-5" style="text-align: center">
                <h4 class="font_class">Follow Us On</h4>
                <a href="https://www.facebook.com/fashiostreet/" class="facebook" target="_blank">
                    <i class="fa fa-facebook-square" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://twitter.com/Fashiostreet10/" class="twitter" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://www.instagram.com/fashiostreet10/" class="Insta" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://www.linkedin.com/company/fashiostreet/" class="linkedIn" target="_blank">
                    <i class="fa fa-linkedin-square" aria-hidden="true"></i>
                </a>&nbsp;
                <a href="https://plus.google.com/u/0/105052627957777439787" class="google" target="_blank">
                    <i class="fa fa-google" aria-hidden="true"></i>
                </a>
                <a href="https://msg91.com/startups/?utm_source=startup-banner" target="_blank"  style="margin-top:-10px"><img src="https://msg91.com/images/startups/msg91Badge.png" id="msg91" width="70" height="50" title="MSG91 - SMS for Startups" alt="Bulk SMS - MSG91"></a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <p class="text-center font_class" ><i class="fa fa-copyright" aria-hidden="true"></i>&nbsp;Copyright 2017  @  FashioStreet.&nbsp;&nbsp;All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

<!-- **************************************______Footer______*********************************-->



<!-- <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script> -->
<!-- Core js bootstrap.min.js  -->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/home.js') }}"></script>
<!-- Core css For material Design Lite -->
<script>
    var token = localStorage.getItem('token');
    var local_id = localStorage.getItem('local_id');
    if(token != null || local_id != null)
    {
        $('.js_hide_login').hide();
        $('.js_show_login').show();
    }
    else{
        $('.js_hide_login').show();
        $('.js_show_login').hide();
    }
    var _0x1a83=["\x63\x6C\x69\x63\x6B","\x2E\x6A\x73\x5F\x6C\x6F\x67\x6F\x75\x74","\x6C\x6F\x63\x61\x6C\x5F\x69\x64","\x72\x65\x6D\x6F\x76\x65\x49\x74\x65\x6D","\x74\x6F\x6B\x65\x6E","\x75\x73\x65\x72\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6C\x6C\x79\x20\x6C\x6F\x67\x6F\x75\x74","\x68\x74\x6D\x6C","\x73\x68\x6F\x77","\x2E\x74\x6F\x61\x73\x74","\x68\x69\x64\x65","\x6F\x6E"];$(document)[_0x1a83[10]](_0x1a83[0],_0x1a83[1],function(){localStorage[_0x1a83[3]](_0x1a83[2]);localStorage[_0x1a83[3]](_0x1a83[4]);$(_0x1a83[8])[_0x1a83[7]]()[_0x1a83[6]](_0x1a83[5]);clearTimeout(clearTime);clearTime= setTimeout(function(){$(_0x1a83[8])[_0x1a83[9]]()},2000)})
</script>
<!-- Script For Mobile Responsive Modal -->
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "Name" : "Fashiostreet",
  "url": "https://www.fashiostreet.com",
  "logo": "https://www.fashiostreet.com/assets/img/fashiostreet_logo.png",
  "description": "Fashiostreet is local shopping search where people can find best fashion products like clothing, footwear, watches and accessories from their city and get free home delivery with TRY & BUY Feature available where they can order 3 products they like and try instantly when delivered & then buy the only products they liked",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+91 8600198512",
    "contactType": "customer service",
    "areaServed": "India",
    "availableLanguage": [
      "English",
      "Hindi",
      "Marathi"
    ]
  }],
  "sameAs" : [
	            	"https://www.facebook.com/fashiostreet/",
	            	"https://www.instagram.com/fashiostreet_official/",
	            	"https://www.linkedin.com/company/fashiostreet/",
	            	"https://plus.google.com/u/0/105052627957777439787/"
	            ],
  "foundingdate":"February 2018",
  "founder":"Amit Ithape, Manoj Nerkar, Sagar Shinde"
}
</script>


</body>
</html>