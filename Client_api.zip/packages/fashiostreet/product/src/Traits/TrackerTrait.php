<?php
namespace fashiostreet\product\Traits;
use fashiostreet\product\Exceptions\SystemException;
use Illuminate\Support\Facades\DB;

trait TrackerTrait{
    public function getSelectedProduct($order_id)
    {
        $product = (array) DB::select('CALL GetOrderedProduct(?,?,?)',[$order_id,0,30]);
		for($i=0;$i < count($product);$i++)
		{
			$image = explode(",",$product[$i]->image);
			$image = 'http://35.200.133.97/products/compress220X258/'.$image[0];
			$product[$i]->image = $image;
			unset($image);
		}
        if(count($product) <= 0)
        {
            throw new SystemException('No product found at order');
        }
        return $product;
    }
}